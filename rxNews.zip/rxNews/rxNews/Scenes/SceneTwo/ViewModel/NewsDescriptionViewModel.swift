//
//  NewsDescriptionViewModel.swift
//  rxNews
//
//  Created by Fedor Losev on 20.01.2022.
//

import RxSwift
import UIKit

protocol NewsDescriptionViewModelProtocol {
    var networkService: NetworkServiceProtocol? { get set }
    var coordinator: NewsDescriptionCoordinator? { get set }
    var itemProperty: NewsArticles? { get set }
    
    func viewDidDisappear()
    func getImg(by str: String?) -> Observable<UIImage>?
    func openSafari()
    func getNewsDate() -> String
    func getNewsDescription() -> String
    func getNewsTitle() -> String
    func getUrlToImage() -> String
}

class NewsDescriptionViewModel: NewsDescriptionViewModelProtocol, NewsDateFormatter {
    
    var networkService: NetworkServiceProtocol?
    weak var coordinator: NewsDescriptionCoordinator?
    var itemProperty: NewsArticles?
    
    func viewDidDisappear() {
        coordinator?.didFinishNewsDescription()
    }
    
    func getImg(by str: String?) -> Observable<UIImage>? {
        guard let str = str, !str.isEmpty else { return Observable.just(UIImage(named: defaulImageName)!) }
        return networkService?.fetchNetworkDataImage(by: str)
    }
    
    func openSafari() {
        guard let strUrl = itemProperty?.url else { return }
        guard let url = URL(string: strUrl) else { return }
        if UIApplication.shared.canOpenURL(url){
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    func getNewsDate() -> String {
        return getDate(itemProperty?.publishedAt ?? "")
    }
    
    func getNewsDescription() -> String {
        return itemProperty?.description ?? ""
    }
    
    func getNewsTitle() -> String {
        return itemProperty?.title ?? ""
    }
    
    func getUrlToImage() -> String {
        return itemProperty?.urlToImage ?? ""
    }
    
    deinit {
        print("!!! deinit NewsDescriptionViewModel")
    }
    
}
