//
//  NewsDescriptionModel.swift
//  rxNews
//
//  Created by Fedor Losev on 25.01.2022.
//

import Foundation
import UIKit


struct NewsDescriptionModel {
    let newsDescriptionTitle: String
    let newsDescriptionImage: UIImage
    let newsDescriptionLabel: String
    let newsDescriptionData: String
}
