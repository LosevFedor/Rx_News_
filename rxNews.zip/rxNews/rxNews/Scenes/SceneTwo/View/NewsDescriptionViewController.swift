//
//  NewsDescriptionViewController.swift
//  rxNews
//
//  Created by Fedor Losev on 20.01.2022.
//

import UIKit
import RxSwift

class NewsDescriptionViewController: UIViewController, Storyborded {

    var viewModel: NewsDescriptionViewModel?
    var bag = DisposeBag()
    
    @IBOutlet weak var titleNews: UILabel!
    @IBOutlet weak var imgNews: UIImageView!
    @IBOutlet weak var descriptionNews: UILabel!
    @IBOutlet weak var dateNews: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setPropertyDescription()
    }
    
    private func setPropertyDescription() {
        titleNews.text = viewModel?.getNewsTitle()
        viewModel?
            .getImg(by: viewModel?.getUrlToImage())?
            .observeOn(MainScheduler.instance)
            .bind(to: imgNews.rx.image)
            .disposed(by: bag)
        
        descriptionNews.text = viewModel?.getNewsDescription()
        dateNews.text =  viewModel?.getNewsDate()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        viewModel?.viewDidDisappear()
    }
    
    @IBAction func openNewsUseSafari(_ sender: Any) {
        viewModel?.openSafari()
    }
    
    deinit {
        print("!!! deinit NewsDescriptionViewController")
    }
}
