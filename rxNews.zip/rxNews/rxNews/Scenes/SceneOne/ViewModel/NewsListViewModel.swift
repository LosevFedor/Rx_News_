//
//  NewsListViewModel.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import Foundation
import RxSwift
import RxCocoa

protocol NewsListParamsProtocol {
    var changefirstIndex: PublishSubject<Int> { get set }
    var changelastIndex: PublishSubject<Int> { get set }
    var changeStepIndex: PublishSubject<Int> { get set }
    var changeMaxPages: PublishSubject<Int> { get set }
}

protocol NewsListViewModelProtocol: AnyObject {
    func getImage(by string: String) -> Observable<UIImage>
    func showNewsDescriptionController(with itemProperty: NewsArticles)
    
    var items: BehaviorRelay<[NewsArticles]> { get set }
    var fetchMoreDatas: PublishSubject<Void> { get set }
    var isLoadingSpinnerAvaliable: PublishSubject<Bool> { get set }
    var refreshControlCompelted: PublishSubject<Void> { get set }
    var refreshControlAction: PublishSubject<Void> { get set }
    
    var coordinator: NewsListCoordinator? { get set }
    
    func getNewsDate(by str: String) -> String
}

class NewsListViewModel: NewsListViewModelProtocol, NewsListParamsProtocol, NewsDateFormatter {
    private let networkService: NetworkServiceProtocol = NetworkService()
    
    private let dummyService = DummyService()
    
    private var pageCounter = 1
    private var maxValue = 1
    private var isPaginationRequestStillResume = false
    private var isRefreshRequstStillResume = false
    
    // Сетить в эти переменные данные после того как вычислили мин макс и шаг для конкретного экрана устройства
    private var firsIndex = 0
    private var lastIndex = 0
    
    // Сетить в эти переменные данные после того как вычислили мин макс и шаг для конкретного экрана устройства
    private var stepIndex = 5
    
    private let bag = DisposeBag()
    
    var fetchMoreDatas = PublishSubject<Void>()
    var items = BehaviorRelay<[NewsArticles]>(value: [])
    var refreshControlAction = PublishSubject<Void>()
    var refreshControlCompelted = PublishSubject<Void>()
    var isLoadingSpinnerAvaliable = PublishSubject<Bool>()
    
    var changefirstIndex = PublishSubject<Int>()
    var changelastIndex = PublishSubject<Int>()
    var changeStepIndex = PublishSubject<Int>()
    var changeMaxPages = PublishSubject<Int>()
    
    var coordinator: NewsListCoordinator?
    
    init(){
        subscriptions()
    }
    
    private func subscriptions() {
        fetchMoreDatas.subscribe { [weak self] _ in
            guard let self = self else { return }
            self.fetchDummyData(page: self.pageCounter,
                                isRefreshControl: false)
        }.disposed(by: bag)
        
        refreshControlAction.subscribe { [weak self] _ in
            self?.refreshControlTriggered()
        }.disposed(by: bag)
        
        changeStepIndex.subscribe { [weak self] step in
            guard let step = step.element else { return }
            self?.stepIndex = step
        }.disposed(by: bag)

        changefirstIndex.subscribe { [weak self] newFirsIndex in
            guard let newFirsIndex = newFirsIndex.element else { return }
            self?.firsIndex = newFirsIndex
        }.disposed(by: bag)

        changelastIndex.subscribe { [weak self] newLastIndex in
            guard let newLastIndex = newLastIndex.element else { return }
            self?.lastIndex = newLastIndex
        }.disposed(by: bag)
    }
       
    private func refreshControlTriggered() {
        isPaginationRequestStillResume = false
        pageCounter = 1
        items.accept([])
        self.changefirstIndex.onNext(self.firsIndex+self.stepIndex)
        self.changelastIndex.onNext(self.lastIndex+self.stepIndex)
        fetchDummyData(page: pageCounter,
                       isRefreshControl: true)
    }
    
    private func fetchDummyData(page: Int, isRefreshControl: Bool) {
        if isPaginationRequestStillResume || isRefreshRequstStillResume { return }
        self.isRefreshRequstStillResume = isRefreshControl
        
        if pageCounter > maxValue  {
            isPaginationRequestStillResume = false
            return
        }
        
        isPaginationRequestStillResume = true
        isLoadingSpinnerAvaliable.onNext(true)
        
        if pageCounter == 1  || isRefreshControl {
            isLoadingSpinnerAvaliable.onNext(false)
        }
        
        if self.pageCounter != 1 && !isRefreshControl {
            let newFirstIndex = self.firsIndex+self.stepIndex
            let newLastIndex = self.lastIndex+self.stepIndex
            updateIndexes(firstIndex: newFirstIndex, lastIndex: newLastIndex)
        } else {
            updateIndexes(firstIndex: 0, lastIndex: 5)
        }
        
        dummyService.fetchItemDatas(indexFrom: firsIndex,
                                    indexTo: lastIndex,
                                    indexStep: stepIndex,
                                    page: page) { [weak self] dummyResponse in
            guard let self = self else { return }
            self.handleDummyData(data: dummyResponse)
            self.isLoadingSpinnerAvaliable.onNext(false)
            self.isPaginationRequestStillResume = false
            self.isRefreshRequstStillResume = false
            self.refreshControlCompelted.onNext(())
        }
    }
    
    private func updateIndexes(firstIndex: Int, lastIndex: Int) {
        self.changefirstIndex.onNext(firstIndex)
        self.changelastIndex.onNext(lastIndex)
    }
    
    private func handleDummyData(data: DummyServiceResponse) {
        maxValue = data.maxPages
        if pageCounter == 1, let finalData = data.datas {
            self.maxValue = data.maxPages
            items.accept(finalData)
        } else if let data = data.datas {
            let oldDatas = items.value
            items.accept(oldDatas + data)
        }
        pageCounter += 1
    }
    
    func getImage(by string: String) -> Observable<UIImage> {
        return networkService.fetchNetworkDataImage(by: string)
    }
    
    func showNewsDescriptionController(with itemProperty: NewsArticles) {
        coordinator?.startDescriptionNews(with: itemProperty)
    }
    
    func getNewsDate(by str: String) -> String {
        return getDate(str)
    }
}
