//
//  NewsListViewController.swift
//  rxNews
//
//  Created by Fedor Losev on 02.01.2022.
//

import UIKit
import RxSwift

let defaulImageName = "defImage"

class NewsListViewController: UIViewController, Storyborded {
    
    weak var coordinator: AppCoordinator?
    var viewModel: NewsListViewModelProtocol?
    
    @IBOutlet weak var tableView: UITableView!
    
    private let cellIdentifire = "NewsCell"
    private let bag = DisposeBag()
    
    private lazy var viewSpinner: UIView = {
        let view = UIView(frame: CGRect(
            x: 0,
            y: 0,
            width: view.frame.size.width,
            height: 100)
        )
        let spinner = UIActivityIndicatorView()
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.startAnimating()
        return view
    }()
    
    private lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshControl.addTarget(self, action: #selector(refreshControlTriggered), for: .valueChanged)
        tableViewBind()
    }
    
    @objc private func refreshControlTriggered() {
        viewModel?.refreshControlAction.onNext(())
    }
    
    private func tableViewBind() {
        viewModel?
            .items
            .observeOn(MainScheduler.instance)
            .bind(to: tableView.rx.items(cellIdentifier: cellIdentifire , cellType: NewsCell.self)) { [weak self] index, model, cell in
                guard let self = self else { return }
                
                self.viewModel?.getImage(by: model.urlToImage ?? defaulImageName)
                    .observeOn(MainScheduler.instance)
                    .bind(to: cell.newsImage.rx.image)
                    .disposed(by: self.bag)
                
                
                cell.newsTitle.text = model.title
                let newsDateFormatter = self.viewModel?.getNewsDate(by: model.publishedAt ?? "")
                cell.newsDate.text = newsDateFormatter
            }.disposed(by: bag)
        
        tableView.refreshControl = self.refreshControl
        
        tableView.rx.didScroll.subscribe { [weak self] _ in
            guard let self = self else { return }
            let offSetY = self.tableView.contentOffset.y
            let contentHeight = self.tableView.contentSize.height
            let tableHeight = self.tableView.frame.size.height
            
            if offSetY > (contentHeight - tableHeight + 200) {
                self.viewModel?.fetchMoreDatas.onNext(())
            }
        }.disposed(by: bag)
        
        viewModel?.isLoadingSpinnerAvaliable.subscribe { [weak self] isAvaliable in
            guard let isAvaliable = isAvaliable.element,
                  let self = self else { return }
            self.tableView.tableFooterView = isAvaliable ? self.viewSpinner : UIView(frame: .zero)
        }.disposed(by: bag)
        
        viewModel?.refreshControlCompelted.subscribe { [weak self] _ in
            guard let self = self else { return }
            self.refreshControl.endRefreshing()
        }.disposed(by: bag)
        
        tableView
            .rx
            .itemSelected
            .do(onNext: { [weak self] indexPath in
                self?.tableView.deselectRow(at: indexPath, animated: true)
            }).subscribe { [weak self] indexPath in
                guard let index = indexPath.event.element?.row else { return }
                guard let itemPropertys = self?.viewModel?.items.value[index] else { return }
                self?.viewModel?.showNewsDescriptionController(with: itemPropertys)
            }.disposed(by: bag)
    }
}
