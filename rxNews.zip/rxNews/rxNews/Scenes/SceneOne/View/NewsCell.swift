//
//  NewsCell.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import UIKit

class NewsCell: UITableViewCell {
    
    @IBOutlet weak var newsImage: UIImageView!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var newsDate: UILabel!
    
}
