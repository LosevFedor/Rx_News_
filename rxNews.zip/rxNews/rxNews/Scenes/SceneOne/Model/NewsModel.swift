//
//  NewsModel.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import Foundation

struct News: Decodable {
    let status: String?
    let totalResults: Int
    let articles: [NewsArticles]?
}

struct NewsArticles: Decodable {
    let author: String?
    let title: String?
    let description: String?
    let url: String?
    let urlToImage: String?
    let publishedAt: String?
    let content: String?
}
