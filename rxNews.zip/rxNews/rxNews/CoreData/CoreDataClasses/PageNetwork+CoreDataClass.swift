//
//  PageNetwork+CoreDataClass.swift
//  rxNews
//
//  Created by Fedor Losev on 06.01.2022.
//
//

import Foundation
import CoreData

@objc(PageNetwork)
public class PageNetwork: NSManagedObject {

}
