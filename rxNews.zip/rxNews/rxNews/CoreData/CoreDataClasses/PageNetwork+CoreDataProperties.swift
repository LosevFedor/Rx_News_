//
//  PageNetwork+CoreDataProperties.swift
//  rxNews
//
//  Created by Fedor Losev on 06.01.2022.
//
//

import Foundation
import CoreData


extension PageNetwork {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PageNetwork> {
        return NSFetchRequest<PageNetwork>(entityName: "PageNetwork")
    }

    @NSManaged public var articles: NSOrderedSet?

}

// MARK: Generated accessors for articles
extension PageNetwork {

    @objc(insertObject:inArticlesAtIndex:)
    @NSManaged public func insertIntoArticles(_ value: Articles, at idx: Int)

    @objc(removeObjectFromArticlesAtIndex:)
    @NSManaged public func removeFromArticles(at idx: Int)

    @objc(insertArticles:atIndexes:)
    @NSManaged public func insertIntoArticles(_ values: [Articles], at indexes: NSIndexSet)

    @objc(removeArticlesAtIndexes:)
    @NSManaged public func removeFromArticles(at indexes: NSIndexSet)

    @objc(replaceObjectInArticlesAtIndex:withObject:)
    @NSManaged public func replaceArticles(at idx: Int, with value: Articles)

    @objc(replaceArticlesAtIndexes:withArticles:)
    @NSManaged public func replaceArticles(at indexes: NSIndexSet, with values: [Articles])

    @objc(addArticlesObject:)
    @NSManaged public func addToArticles(_ value: Articles)

    @objc(removeArticlesObject:)
    @NSManaged public func removeFromArticles(_ value: Articles)

    @objc(addArticles:)
    @NSManaged public func addToArticles(_ values: NSOrderedSet)

    @objc(removeArticles:)
    @NSManaged public func removeFromArticles(_ values: NSOrderedSet)

}

extension PageNetwork : Identifiable {

}
