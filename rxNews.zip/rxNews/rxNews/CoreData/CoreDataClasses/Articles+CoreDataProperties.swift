//
//  Articles+CoreDataProperties.swift
//  rxNews
//
//  Created by Fedor Losev on 06.01.2022.
//
//

import Foundation
import CoreData


extension Articles {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Articles> {
        return NSFetchRequest<Articles>(entityName: "Articles")
    }

    @NSManaged public var authorNews: String?
    @NSManaged public var titleNews: String?
    @NSManaged public var descriptionNews: String?
    @NSManaged public var urlNews: String?
    @NSManaged public var urlToImageNews: String?
    @NSManaged public var publishedAt: String?
    @NSManaged public var content: String?
    @NSManaged public var article: PageNetwork?

}

extension Articles : Identifiable {

}
