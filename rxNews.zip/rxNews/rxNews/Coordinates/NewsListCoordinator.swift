//
//  NewsListCoordinator.swift
//  rxNews
//
//  Created by Fedor Losev on 18.01.2022.
//

import Foundation
import UIKit

final class NewsListCoordinator: Coordinator {
    private(set) var childCoordinators: [Coordinator] = []
    private let navigatorController: UINavigationController
        
    init(navigationController: UINavigationController) {
        self.navigatorController = navigationController
    }
    
    func start() {
        let newsListViewController = NewsListViewController.instantiate()
        let newsListViewModel: NewsListViewModelProtocol = NewsListViewModel()
        newsListViewModel.coordinator = self
        newsListViewController.viewModel = newsListViewModel
        navigatorController.setViewControllers([newsListViewController], animated: false)
    }
    
    func startDescriptionNews(with itemProperty: NewsArticles) {
        let newsDescriptionCoordinator = NewsDescriptionCoordinator(navigatorController: navigatorController)
        newsDescriptionCoordinator.parentCoordinator = self
        let newsDescriptionViewModel = NewsDescriptionViewModel()
        let networkService: NetworkServiceProtocol = NetworkService()
        newsDescriptionViewModel.itemProperty = itemProperty
        newsDescriptionViewModel.networkService = networkService
        newsDescriptionCoordinator.newsDescriptionViewModel = newsDescriptionViewModel
        childCoordinators.append(newsDescriptionCoordinator)
        newsDescriptionCoordinator.start()
    }
    
    func childDidFinish(_ childCoordinator: Coordinator) {
        if let index = childCoordinators.firstIndex(where: { coordinator -> Bool in
            return childCoordinator === coordinator
        }) {
            childCoordinators.remove(at: index)
        }
    }
}
