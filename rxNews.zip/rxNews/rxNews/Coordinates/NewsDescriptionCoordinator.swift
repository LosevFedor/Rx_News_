//
//  NewsDescriptionCoordinator.swift
//  rxNews
//
//  Created by Fedor Losev on 20.01.2022.
//

import Foundation
import UIKit

class NewsDescriptionCoordinator: Coordinator {
    private(set) var childCoordinators: [Coordinator] = []
    private let navigatorController: UINavigationController
    
    var newsDescriptionViewModel: NewsDescriptionViewModel?
    var parentCoordinator: NewsListCoordinator?
    
    init(navigatorController: UINavigationController){
        self.navigatorController = navigatorController
    }
    
    func start() {
        let newsDescriptionViewController = NewsDescriptionViewController.instantiate()
        newsDescriptionViewModel?.coordinator = self
        newsDescriptionViewController.viewModel = newsDescriptionViewModel
        navigatorController.pushViewController(newsDescriptionViewController, animated: true)
    }
    
    func didFinishNewsDescription() {
        parentCoordinator?.childDidFinish(self)
    }
    
    deinit {
        print("!!! deinit NewsDescriptionCoordinator")
    }
}
