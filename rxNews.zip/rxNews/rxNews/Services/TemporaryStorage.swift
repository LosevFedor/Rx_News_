//
//  TemporaryStorage.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import Foundation
import RxSwift
import RxCocoa

protocol TemporaryStorageProtocol {
    var cacheDatas: Observable<[NewsArticles]> { get set}
}

class TemporaryStorage: TemporaryStorageProtocol {
    
    private let networkSerwices: NetworkServiceProtocol = NetworkService()
    private let persistenStorage: PersistenStorageProtocol = PersistenStorage()
    
    lazy var cacheDatas: Observable<[NewsArticles]> = {
        return getTemporaryData()
    }()
    
    private func getTemporaryData() -> Observable<[NewsArticles]> {
        if persistenStorage.isPersistenStorageEmpty() {
            let cach = networkSerwices.fetchNetworkData()
            persistenStorage.setDataToPersistenStorage(by: cach)
            return cach
        }
        return persistenStorage.fetchPersistenData()
    }
}
