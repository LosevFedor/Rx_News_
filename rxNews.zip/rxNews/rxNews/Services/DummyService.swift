//
//  DummyService.swift
//  rxNews
//
//  Created by Fedor Losev on 18.01.2022.
//

import Foundation
import RxSwift

struct DummyServiceResponse {
    let maxPages: Int
    let hasMore: Bool
    let datas: [NewsArticles]?
}

struct DummyService {
    private var cache: TemporaryStorageProtocol = TemporaryStorage()
    private let bag = DisposeBag()
    private let durationTime: TimeInterval = 2
    
    let group = DispatchGroup()
    let backgroundQueue = DispatchQueue.global(qos: .background)
    
    func fetchItemDatas(indexFrom: Int, indexTo: Int, indexStep: Int, page: Int, completion: @escaping (DummyServiceResponse) -> ()) {
        var partOfArrayArticles = [NewsArticles]()
        var maxPages = 0
        
        group.enter()
        cache.cacheDatas.subscribeOn(ConcurrentDispatchQueueScheduler.init(queue: backgroundQueue)).subscribe { items in
            guard let items = items.element else { return }
            maxPages = items.count / indexStep
            for index in indexFrom ..< indexTo {
                partOfArrayArticles.append(items[index])
            }
            group.leave()
        }.disposed(by: bag)
        group.wait()
        
        if page > maxPages {
            DispatchQueue.main.asyncAfter(deadline: .now() + durationTime) {
                completion(DummyServiceResponse(maxPages: maxPages,
                                                hasMore: false,
                                                datas: nil))
            }
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + durationTime) {
                completion(DummyServiceResponse(maxPages: maxPages,
                                                hasMore: page != maxPages,
                                                datas: partOfArrayArticles))
            }
        }
    }
}
