//
//  PersistenStorage.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import CoreData
import RxSwift

protocol PersistenStorageProtocol {
    func saveContext()
    func isPersistenStorageEmpty() -> Bool
    func fetchPersistenData() -> Observable<[NewsArticles]>
    func setDataToPersistenStorage(by temporaryData: Observable<[NewsArticles]>)
}

class PersistenStorage: PersistenStorageProtocol {
    
    private let backgroundQueue = DispatchQueue.global()
    private var currentPageNetwork: PageNetwork?
    private let bag = DisposeBag()
    
    func fetchPersistenData() -> Observable<[NewsArticles]> {
        let articlesNews: NSFetchRequest<Articles> = Articles.fetchRequest()
        return Observable.create { [weak self] observ in
            guard let self = self else { return Disposables.create() }
            do{
                let articlesResults = try self.managedContext.fetch(articlesNews)
                var newsArticles = [NewsArticles]()
                for article in articlesResults {
                    let art = NewsArticles(author: article.authorNews,
                                           title: article.titleNews,
                                           description: article.descriptionNews,
                                           url: article.urlNews,
                                           urlToImage: article.urlToImageNews,
                                           publishedAt: article.publishedAtNews,
                                           content: article.contentNews)
                    newsArticles.append(art)
                }
                observ.onNext(newsArticles)
            } catch {
                let errText = NSError(domain: "Can't get Fetch from CORE DATA:", code: -4, userInfo: nil)
                print(errText)
            }
            return Disposables.create()
        }.subscribeOn(ConcurrentDispatchQueueScheduler(queue: backgroundQueue))
    }
    
    func isPersistenStorageEmpty() -> Bool {
        let pageNetwork: NSFetchRequest<PageNetwork> = PageNetwork.fetchRequest()
        do {
            let result = try managedContext.fetch(pageNetwork)
            if result.count > 0 {
                return false
            }
            return true
        } catch let err as NSError {
            let errText = NSError(domain: "Can't get Data from PersistenStorage: \(err.userInfo)", code: -3, userInfo: nil)
            print(errText)
            return true
        }
    }
    
    func setDataToPersistenStorage(by temporaryData: Observable<[NewsArticles]>) {
        currentPageNetwork = PageNetwork(context: self.managedContext)
        temporaryData
            .subscribeOn(ConcurrentDispatchQueueScheduler(queue: backgroundQueue))
            .subscribe { [weak self] arrArticles in
                guard let self = self else { return }
                guard let arrArticles = arrArticles.element else { return }
                for art in arrArticles {
                    let article = Articles(context: self.managedContext)
                    article.authorNews = art.author
                    article.contentNews = art.content
                    article.descriptionNews = art.description
                    article.publishedAtNews = art.publishedAt
                    article.titleNews = art.title
                    article.urlNews = art.url
                    article.urlToImageNews = art.urlToImage
                    self.currentPageNetwork?.addToArticles(article)
                }
                self.saveContext()
            }.disposed(by: bag)
    }
    
    lazy var managedContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "rxNews")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    func saveContext () {
        let context = managedContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
