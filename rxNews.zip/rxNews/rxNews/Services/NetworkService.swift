//
//  NetworkService.swift
//  rxNews
//
//  Created by Fedor Losev on 04.01.2022.
//

import Foundation
import RxSwift

protocol NetworkServiceProtocol {
    func fetchNetworkData() -> Observable<[NewsArticles]>
    func fetchNetworkDataImage(by string: String) -> Observable<UIImage>
}

class NetworkService: NetworkServiceProtocol {
    private let backgroundQueue = DispatchQueue.global(qos: .default)
    private let group = DispatchGroup()
    
    func fetchNetworkData() -> Observable<[NewsArticles]> {
        return Observable.create { observ in
            var allAricles = [NewsArticles]()
            for page in 1..<2 {
            self.group.enter()
               let strUrl = "https://newsapi.org/v2/everything?q=android&from=2019-04-00&sortBy=publishedAt&apiKey=26eddb253e7840f988aec61f2ece2907&page=\(page)"
                
                let url = URL(string: strUrl)!
                let request = URLRequest(url: url)
                URLSession.shared.dataTask(with: request) { data, responce, err in
                    guard let data = data else { return }
                    
                    do {
                        let newsPage = try JSONDecoder().decode(News.self, from: data)
                        guard let newsPage = newsPage.articles else { return }
                        
                        for article in newsPage {
                            allAricles.append(article)
                        }
                        self.group.leave()
                    } catch {
                        self.group.leave()
                        observ.onError(error)
                    }
                }.resume()
            }
            self.group.wait()
            observ.onNext(allAricles)
            return Disposables.create()
        }.subscribeOn(ConcurrentDispatchQueueScheduler(queue: backgroundQueue))
    }
    
    func fetchNetworkDataImage(by string: String) -> Observable<UIImage> {
        return Observable.create { observ in
            let url = URL(string: string)
            guard let url = url else { return Disposables.create() }
            guard let data = try? Data(contentsOf: url) else { return Disposables.create()}
            let img = UIImage(data: data)
            observ.onNext((img ?? UIImage(named: "defImage"))!)
            return Disposables.create()
        }.subscribeOn(ConcurrentDispatchQueueScheduler(queue: backgroundQueue))
    }
}
