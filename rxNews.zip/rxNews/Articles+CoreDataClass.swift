//
//  Articles+CoreDataClass.swift
//  rxNews
//
//  Created by Fedor Losev on 11.01.2022.
//
//

import Foundation
import CoreData

@objc(Articles)
public class Articles: NSManagedObject {

}
